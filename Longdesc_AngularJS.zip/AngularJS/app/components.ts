export { AppComponent } from './app.component';
import { AppComponent } from './app.component';
export { NotificationButtonComponent } from './notification-button.component';
import { NotificationButtonComponent } from './notification-button.component';
export { ModalComponent } from './modal.component';
import { ModalComponent } from './modal.component';


export const declarations = [
  AppComponent,
  NotificationButtonComponent,
  ModalComponent
]